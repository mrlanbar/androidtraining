package btm.project.loginform;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.lang.*;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;
public class MainActivity extends AppCompatActivity {
    EditText UserName,Password;
    Button btnLogin;
    String tempUserName;
    String tempPassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_main );
        UserName=findViewById ( R.id.UserName );
        Password=findViewById (R.id.Password  );
        btnLogin=findViewById ( R.id.Login );
        parseJson ();
        final ArrayList< HashMap< String, String>> LoginInformation = null;
        Collections.copy(JSONtoArray (),LoginInformation);

        btnLogin.setOnClickListener ( new View.OnClickListener(){
            public void onClick(View v) {

                tempUserName = UserName.toString ();
                tempPassword=Password.toString ();
                for(int i = 0 ;i<LoginInformation.size ();i++){
                   String [] temp = new String[10];
                   temp[i] = LoginInformation.get ( "UserName" );


                }

            }

        });









    }
    public String parseJson() {
        String JSON;
    try{
    InputStream is = this.getAssets().open ( "LoginInformation.json" );
    int size = is.available ();
    byte[] b = new byte[size];
    is.read ( b );
    JSON = new String ( b, "UTF-8"  );

}
    catch(IOException e){
        e.printStackTrace ( );

        return "Your Code is Shit it doesn't work";
}

        return JSON;

    }


    public ArrayList< HashMap< String, String>> JSONtoArray(){
        ArrayList<HashMap<String,String>> al = null;
        HashMap<String,String>list;

        try {
            JSONObject obj = new JSONObject ( parseJson () );
            JSONArray JA = new JSONArray ( obj.getJSONArray ( "LoginInformation" ) );
             list = new HashMap <> ();
             al = new ArrayList <> (  );

            for(int i=0;i<JA.length ();i++){
                JSONObject JO = JA.getJSONObject ( i );
                String UserName = JO.getString ( "UserName" );
                String Password = JO.getString ( "Password" );
                list.put ( "UserName" ,UserName );
                list.put ("Password" , Password);
                al.add ( list );

            }



        } catch (JSONException e) {
            e.printStackTrace ( );
        }

        return al;

    }


}