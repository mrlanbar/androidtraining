package btm.project.loginform;

import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileWriter;
import java.io.IOException;

public class createJSONFile {
    JSONObject obj = new JSONObject (  );
    
    public void StartJsonFile(){
        JSONObject obj = new JSONObject (  );
        try {
            obj.put ( "User Name","WinYanNaingHtunt" );
            obj.put ( "Password" , "WinYan*123" );
            try (FileWriter fw = new FileWriter ( "LoginInfo.json")) {

                fw.write ( obj.toString () );
                fw.flush ();
                 Log.e ( "Hello",obj.toString ());

            }
        } catch (JSONException | IOException e) {
            e.printStackTrace ( );
        }

    }
    
    
}
